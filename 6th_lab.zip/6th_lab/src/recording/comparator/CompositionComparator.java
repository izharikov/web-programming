package recording.comparator;

import recording.entity.composition.Composition;

import java.util.Comparator;

/**
 * comparator for composition interface
 */
public interface CompositionComparator extends Comparator<Composition> {
}
